package com.emse.spring.faircorp.model;

public enum WindowStatus { OPEN, CLOSED}
