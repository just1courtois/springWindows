package com.emse.spring.faircorp.model;

public enum HeaterStatus { ON, OFF}
