package com.emse.spring.faircorp.hello;

public interface GreetingService {
    void greet(String name);
}

