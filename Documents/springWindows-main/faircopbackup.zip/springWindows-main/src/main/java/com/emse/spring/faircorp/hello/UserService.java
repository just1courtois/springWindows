package com.emse.spring.faircorp.hello;

public interface UserService {
    void greetAll();
}
